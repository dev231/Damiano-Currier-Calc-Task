﻿using System;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using ChangeCalculator;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ChangeCalculatorUnitTests
{
    [TestClass]
    public class ChangeItemUnitTests
    {

        double coinValue;
        string expectedValue1;
        string expectedValue2;
        string expectedValue3;
        string expectedValue4;
        string expectedValue;
        string actualValue;

        SalesItem salesTest = new SalesItem();
        PaymentItem paymentTest = new PaymentItem();
        ChangeItem change = new ChangeItem();

        private class FakePriceInput : IUserInput
        {
            public string GetInput()
            {
                return "5.50";
            }
        }

        private class FakePaymentInput : IUserInput
        {
            public string GetInput()
            {
                return "20";
            }
        }

        string GetPoundFormat(double aValue)
        {
            return aValue.ToString("C");
        }
        private string GetPennyFormat(double aValue)
        {
            return (aValue * 100).ToString() + "p";
        }

        [TestMethod]
        public void Change_SplitChange_Return1x10_2x2_1x050()
        {

            salesTest.AskPrice(new FakePriceInput());
            paymentTest.AskPayment(new FakePaymentInput());
            change.CalculateChange(salesTest.Price, paymentTest.Pay);

            using (GetConsoleOutput consoleOutput = new GetConsoleOutput())
            {
                change.SplitChange();
                actualValue = Regex.Replace(consoleOutput.GetOuput(), @"\t|\n|\r", " ");


                coinValue = 10;
                expectedValue1  = "1" + "  " + GetPoundFormat(coinValue) + "  ";

                coinValue = 2;
                expectedValue2 = "2" + "  " + GetPoundFormat(coinValue) + "  ";

                coinValue = 0.50;
                expectedValue3 = "1" + "  " + GetPennyFormat(coinValue) + "  ";

                expectedValue4 = "Total Change : " + change.totalChange.ToString("C", new CultureInfo("en-GB")) + "  ";

                expectedValue = expectedValue1 + expectedValue2 + expectedValue3 + expectedValue4;

                Assert.AreEqual(expectedValue, actualValue);
            }
        }

        [TestMethod]
        public void Change_SplitChange_ReturnDifferent()
        {
            salesTest.AskPrice(new FakePriceInput());
            paymentTest.AskPayment(new FakePaymentInput());
            change.CalculateChange(salesTest.Price, paymentTest.Pay);

            using (GetConsoleOutput consoleOutput = new GetConsoleOutput())
            {
                change.SplitChange();
                actualValue = Regex.Replace(consoleOutput.GetOuput(), @"\t|\n|\r", " ");

                coinValue = 10;
                expectedValue1 = "2" + "  " + GetPoundFormat(coinValue) + "  ";

                coinValue = 2;
                expectedValue2 = "2" + "  " + GetPoundFormat(coinValue) + "  ";

                coinValue = 0.50;
                expectedValue3 = "1" + "  " +  GetPennyFormat(coinValue) + "  ";

                expectedValue4 = "Total Change : " + change.totalChange.ToString("C", new CultureInfo("en-GB")) + "  ";

                expectedValue = expectedValue1 + expectedValue2 + expectedValue3 + expectedValue4;

                Assert.IsTrue(expectedValue != actualValue);
            }
        }
    }
}
