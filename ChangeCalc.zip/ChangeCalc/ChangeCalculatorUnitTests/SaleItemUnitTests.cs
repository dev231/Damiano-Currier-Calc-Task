﻿using System;
using ChangeCalculator;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ChangeCalculatorUnitTests
{
    [TestClass]
    public class SaleItemUnitTests
    {
        private class FakeCorrectPriceInput : IUserInput
        {
            public string GetInput()
            {
                return "5";
            }
        }

        private class FakeWrongPriceInput : IUserInput
        {
            public string GetInput()
            {
                return "A";
            }
        }

        [TestMethod]
        public void Sales_AskPrice_ReturnsTrue()
        {
            SalesItem salesTest = new SalesItem();
            salesTest.AskPrice(new FakeCorrectPriceInput());


            Assert.IsTrue(salesTest.IsValidPrice);
        }


        [TestMethod]
        public void Sales_AskPrice_ReturnsFalse()
        {
            SalesItem salesTest = new SalesItem();
            salesTest.AskPrice(new FakeWrongPriceInput());


            Assert.IsFalse(salesTest.IsValidPrice);
        }
    }
}
