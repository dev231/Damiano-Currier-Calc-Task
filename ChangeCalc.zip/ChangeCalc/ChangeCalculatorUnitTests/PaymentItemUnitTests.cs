﻿using System;
using System.Runtime.Remoting.Channels;
using ChangeCalculator;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ChangeCalculatorUnitTests
{
    [TestClass]
    public class PaymentItemUnitTests
    {
        private class FakePriceInput : IUserInput
        {
            public string GetInput()
            {
                return "5";
            }
        }

        private class FakeCorrectPaymentInput : IUserInput
        {
            public string GetInput()
            {
                return "10";
            }
        }

        private class FakeWrongPaymentInput : IUserInput
        {
            public string GetInput()
            {
                return "3";
            }
        }

        [TestMethod]
        public void Sales_AskPayment_ReturnsTrue()
        {
            SalesItem salesTest = new SalesItem();
            salesTest.AskPrice(new FakePriceInput());


            PaymentItem paymentTest = new PaymentItem();
            paymentTest.AskPayment(new FakeCorrectPaymentInput());


            Assert.IsTrue(paymentTest.Pay >= salesTest.Price);
        }


        [TestMethod]
        public void Sales_AskPayment_ReturnsFalse()
        {
            SalesItem salesTest = new SalesItem();
            salesTest.AskPrice(new FakePriceInput());


            PaymentItem paymentTest = new PaymentItem();
            paymentTest.AskPayment(new FakeWrongPaymentInput());


            Assert.IsFalse(paymentTest.Pay >= salesTest.Price);
        }
    }
}
