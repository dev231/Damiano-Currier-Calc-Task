using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Change Calculator UnitTests")]
[assembly: AssemblyDescription("Change Calculator UnitTests")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Change Calculator UnitTests")]
[assembly: AssemblyProduct("Change Calculator UnitTests")]
[assembly: AssemblyCopyright("Copyright ©  2019 Damiano Curreri. All right are reserved")]
[assembly: AssemblyTrademark("Copyright ©  2019 Damiano Curreri. All right are reserved")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("ec1b7b78-e672-4d4b-9f51-0aa071cff108")]

// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
