﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChangeCalculator
{


    class Program
    {
        static void Main(string[] args)
        {
            IUserInput priceInput = new PriceInput();
            IUserInput paymentInput = new PaymentInput();

            SalesItem sales = new SalesItem();
            PaymentItem payment = new PaymentItem();
            ChangeItem change = new ChangeItem();

            do
            {
                sales.AskPrice(priceInput);
            } while (!sales.IsValidPrice);


            if (sales.IsValidPrice == true)
            {
                do
                {
                    payment.AskPayment(paymentInput);

                } while (payment.Pay <= sales.Price);

            }

            change.CalculateChange(sales.Price, payment.Pay);


            if (change.Change > 0)
            {
                change.SplitChange();
            }

            Console.Read();
        }
    }
}
