﻿using System.Globalization;

namespace ChangeCalculator
{

    public class ChangeItem
    {
        ILog consoleLog = new WriteToConsole();

        private double _change;
        public double totalChange;

        public double Change
        {
            get => _change;
            set => _change = value;
        }


        public void CalculateChange(double aPrice, double aPayment)
        {
            Change = aPayment - aPrice;
        }

        private string GetPoundFormat(double aValue)
        {
            return aValue.ToString("C");
        }

        private string GetPennyFormat(double aValue)
        {
            return (aValue * 100).ToString() + "p";
        }

        public void SplitChange()
        {
            double[] coinValue = { 200, 100, 50, 20, 10, 5, 2, 1, 0.5, 0.2, 0.1, 0.05 };
            uint[] result = new uint[coinValue.Length];

            totalChange = Change;

            consoleLog.Log("Your change is : ");

            for (int i = 0; i < coinValue.Length; ++i)
            {
                result[i] = (uint)(Change / coinValue[i]);

                if (result[i] > 0)
                {
                    Change = Change % coinValue[i];

                    if (coinValue[i] >= 1)
                    {
                        consoleLog.Log(result[i] + " \t" + GetPoundFormat(coinValue[i]));
                    }
                    else
                    {
                        consoleLog.Log(result[i] + " \t" + GetPennyFormat(coinValue[i]));
                    }
                }
            }

            consoleLog.Log("Total Change : " + GetPoundFormat(totalChange));
        }
    }
}