﻿using System;

namespace ChangeCalculator
{
    public class SalesItem
    {
        ILog consoleLog = new LogToConsole();

        private double _productPrice;
        private string _input;

        public double Price
        {
            get => _productPrice;
            set => _productPrice = value;
        }

        public bool IsValidPrice { get; private set; }

        public void AskPrice(IUserInput input)
        {
            consoleLog.Log("Enter the price: ");
            _input = input.GetInput();


            if (!string.IsNullOrEmpty(_input) && double.TryParse(_input, out _productPrice))
            {
                Price = double.Parse(_input);
                IsValidPrice = true;
            }
            else
            {
                consoleLog.Log("This is not a valid price. Please enter a valid price");
                IsValidPrice = false;

            }
        }
    }
}