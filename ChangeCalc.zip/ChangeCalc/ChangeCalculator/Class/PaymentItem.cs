﻿namespace ChangeCalculator
{
    public class PaymentItem
    {
        ILog consoleLog = new LogToConsole();

        private double _payment;
        private string _input;

        public double Pay
        {
            get => _payment;
            set => _payment= value;
        }

        public bool IsValidPayment { get; private set; }

        public void AskPayment(IUserInput input)
        {
            consoleLog.Log("Enter the payment: ");
            _input = input.GetInput();


            if (!string.IsNullOrEmpty(_input) && double.TryParse(_input, out _payment))
            {
                Pay = double.Parse(_input);
                IsValidPayment = true;
            }
            else
            {
                consoleLog.Log("This is not a valid paymet. Please enter a valid price");
                IsValidPayment = false;

            }
        }
    }
}