﻿using System;

namespace ChangeCalculator
{
    public interface ILog
    {
        void Log(string aMessage);
    }

    class LogToConsole : ILog
    {
        public void Log(string aMessage)
        {
            Console.WriteLine(aMessage);
        }
    }

    public class WriteToConsole: ILog
    {
        public void Log(string aMessage)
        {
            Console.WriteLine(aMessage);
        }
    }
}