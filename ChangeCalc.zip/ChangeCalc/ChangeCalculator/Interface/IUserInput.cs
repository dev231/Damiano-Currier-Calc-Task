﻿using System;

namespace ChangeCalculator
{
    public interface IUserInput
    {
        string GetInput();
    }

    class PriceInput : IUserInput
    {
        public string GetInput()
        {
            return Console.ReadLine().Trim();
        }
    }

    class PaymentInput : IUserInput
    {
        public string GetInput()
        {
            return Console.ReadLine().Trim();
        }
    }
}